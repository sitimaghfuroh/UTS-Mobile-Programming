package com.example.appsf9;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListSf9 extends RecyclerView.Adapter<ListSf9.ListViewHolder> {
    private ArrayList<Sf9Architecture> listSf9;

    private OnItemClickCallback onItemClickCallback;

    public ListSf9(ArrayList<Sf9Architecture> list) {
        this.listSf9 = list;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_sf9, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        Sf9Architecture nw = listSf9.get(position);

        Glide.with(holder.itemView.getContext())
                .load(nw.getPhoto())
                .apply(new RequestOptions().override(60, 60))
                .into(holder.imgSf9);
        holder.tvNickName.setText(nw.getNickName());
        holder.tvLahir.setText(nw.getLahir());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listSf9.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listSf9.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder{
        ImageView imgSf9;
        TextView tvFullName, tvNickName, tvDetail, tvLahir, tvPosisi;


        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgSf9 = itemView.findViewById(R.id.tv_sf9_photo);
            tvFullName = itemView.findViewById(R.id.tv_full_name);
            tvNickName = itemView.findViewById(R.id.tv_nick_name);
            tvDetail = itemView.findViewById(R.id.tv_detail);
            tvLahir = itemView.findViewById(R.id.tv_lahir);
            tvPosisi = itemView.findViewById(R.id.tv_posisi);

        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Sf9Architecture data);
    }
}
