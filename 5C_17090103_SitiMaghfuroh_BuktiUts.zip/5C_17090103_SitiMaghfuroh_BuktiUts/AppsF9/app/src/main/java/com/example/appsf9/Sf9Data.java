package com.example.appsf9;

import java.util.ArrayList;

public class Sf9Data {
    private static String[] sf9FullName = {
            "SF9",
            "Inseong",
            "Young Bin",
            "Jae Yoon",
            "Dawon",
            "Zuho",
            "Rowoon",
            "Taeyang",
            "Hwiyoung",
            "Chani"


    };

    private static String[] sf9NickName = {
            "Sensational Feeling 9",
            "James Kim",
            "Youngbean",
            "Manly Man",
            "Lee Sang Hyuk",
            "Baek Choding",
            "Choco Milk",
            "Sunshine",
            "Cold City Guy",
            "Chicken Chani"

    };
    private static String[] sf9Detail = {
            "SF9 atau Sensational Feeling 9 (에스에프나인) adalah grup dance baru dari FNC Entertainment yang berangotakan 9 orang. Anggotanya antara lain : In Seong, Young Bin, Jae Yoon, Da Won, Zu Ho, Ro Woon, Tae Yang, Hwi Young, Cha Ni. Pada bulan Desember 2015, FNC Entertainment mengungkapkan akan medebutkan sebuah grup baru melalui sistem pelatihan dengan nama NEOZ SCHOOL (NEOZ).  NEOZ SCHOOL sendiri dibagi 2 grup yaitu Team Dance (In Seong, Young Bin, Jae Yoon, Da Won, Zu Ho, Ro Woon, Tae Yang, Hwi Young, Cha Ni) dan Team Band (Kim Chul Min, Kim Hwan, Seo Dong Sun, Oh Seung Seok). Kedua tim tersebut akan bertarung melalui program survival baru dari Mnet dengan nama D.O.B (Dance or Band). Dalam babak akhir, akhirnya Team Dance yang menang dan berhak debut duluan.",
            "Inseong merupakan member tertua, Dia adalah member terpandai, dan pernah menempuh pendidikan di Inggris selama setahun, Karena memiliki kemampuan dalam berbahasa Inggris, dia menjadi pembicara bahasa Inggris untuk grupnya, Salah satu hobinya adalah makan, Pink adalah warna favorit Inseong, Dulunya dia mantan traine di SM entertainment",
            "Young Bin merupakan anak bungsu, dan mempunyai kakak cowok, dan cewek, Sebagai seorang leader, dia merupakan bapak dalam grup, Dia menyukai warna merah,dan makanan pedas, Youngbin mengaku bahwa dia menyukai skinship, Dia paling banyak melakukan skinship dengan Chani, Epikhigh merupakan grup idolanya",
            "Jaeyoon dulunya tinggal di pinggiran kota, Jaeyoon dulunya tinggal di pinggiran kota, Dia memiliki lesung pipi yang dalam, Karena dia memiliki kemampuan menyanyikan lagu apapun dengan manis, dia dijuluki honey voice, dan bertanggung jawab untuk hal itu, Dia bernyanyi untuk Ost mini drama Girl’s Generation 1979, Jaeyoon memilki ketakutan terhadap ketinggian",
            "Dawon pernah menempuh pendidikan di Spanyol selama 4 bulan, Dia merupakan anak tunggal, Total, terdapat empat tato di tubuhnya. Salah satunya adalah tato bergambar mahkota yang mirip dengan G-dragon, Dia juga merupakan member di acara SBS gameshow, Dawon menyukai wanita yang memiliki mata besar, Dia bermain dalam mini drama SF9 yang berjudul click your heart",
            "Zuho sangat percaya diri saat melakukan sexy dance, Banyak yang menyangka bahwa dia adalah orang yang dingin, sebenarnya dia memilki kepribadian yang hangat, Karena wajahnya, kekuatan utama Zuho adalah pesonanya, Zuho suka mengorok saat tidur XD, dia juga suka mengigau, Suga merupakan panutannya, Dia adalah traine pertama untuk SF9",
            "Rowoon sangat bertalenta dalam hal olahraga, dia bahkan pernah masuk National Soccer Championship, Dia menyukai makanan pedas, Dia merupakan pribadi yang ceria, Rowoon adalah traine kedua SF9, Dia tergabung dalam acara Café Amor",
            "Taeyang memilki kemampuan vocal yang tergolong unik, Dia bisa meniru Junsu JYJ, Taeyang menjadikan Kai, dan D.O sebagai panutan, Dia bisa menari dalam segala jenis musik, Taeyang memiliki selera fashion yang luar biasa",
            "Hwiyoung bisa menirukan suara lumba-lumba, Dia menyukai musik hiphop dan Rap, Walau dia memiliki kepribadian yang ceria, tapi dia merupakan pribadi yang sensitive, Dia bisa menangis karena menonton train to busan, Karena sering melakukan olahraga, dia mempunyai bahu yang kuat",
            "Chani mampu mencapai nada tinggi di SF9, Dia menempuh pendidikan di SOPA, dan lulus tahun 2018, Dulunya dia merupakan traine di Fantagio, Karena dia sangat menyukai ayam, dia ingin tampil di iklan ayam goreng, Moonbin Astro, dan Chanwoo Ikon adalah teman masa kecilnya"


    };
    private static String[] sf9Lahir = {
            "Debut:, Korea Selatan, 5 Oktober 2016",
            "Cheongdam-dong, Korea Selatan, 12 Juli 1993",
            "Gyeonggi-do, Korea Selatan, 23 November 1993",
            "Busan, Korea Selatan, 9 Agustus 1994",
            "Ilsan, Korea Selatan, 24 Juli 1995",
            "Ilsan, Korea Selatan, 4 Juli 1996",
            "Ilsan, Korea Selatan, 7 Agustus 1996",
            "Mokdong, Korea Selatan, 28 Februari 1997",
            "Busan, Korea Selatan,  11 Mei 1999",
            "Hongseong, Korea Selatan, 17 Januari 2000"



    };
    private static String[] sf9Posisi = {
            "Boy Group",
            "Main Vocal",
            "Leader, Lead Rapper",
            "Lead Vocal",
            "Lead Vocal",
            "Main Rapper",
            "Lead Vocal, Visual",
            "Main Vocal, Main Dancer",
            "Vocal, Rapper, Dancer",
            "Maknae, Vocal, Rapper, Main Dancer"


    };
    private static int[] photo = {
            R.drawable.sf9,
            R.drawable.iinseong,
            R.drawable.yyoungbin,
            R.drawable.jjaeyoon,
            R.drawable.ddawon,
            R.drawable.zzuho,
            R.drawable.rrowoon,
            R.drawable.ttaeyang,
            R.drawable.hhwiyoung,
            R.drawable.cchani

    };

    static ArrayList<Sf9Architecture> getListData() {
        ArrayList<Sf9Architecture> list = new ArrayList<>();
        for (int position = 0; position < sf9NickName.length; position++) {
            Sf9Architecture nw = new Sf9Architecture();
            nw.setFullName(sf9FullName[position]);
            nw.setNickName(sf9NickName[position]);
            nw.setDetail(sf9Detail[position]);
            nw.setLahir(sf9Lahir[position]);
            nw.setPosisi(sf9Posisi[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }
}
