package com.example.appsf9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvSf9;
    private ArrayList<Sf9Architecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvSf9 = findViewById(R.id.rv_sf9);
        rvSf9.setHasFixedSize(true);

        list.addAll(Sf9Data.getListData());

        showRecyclerList();
    }
    private void showRecyclerList() {
        rvSf9.setLayoutManager(new LinearLayoutManager(this));
        ListSf9 listBts = new ListSf9(list);
        rvSf9.setAdapter(listBts);

        listBts.setOnItemClickCallback(new ListSf9.OnItemClickCallback() {
            @Override
            public void onItemClicked(Sf9Architecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(Sf9Architecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailSf9.class);
        detailIntent.putExtra(DetailSf9.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailSf9.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailSf9.EXTRA_NICKNAME, nw.getNickName());
        detailIntent.putExtra(DetailSf9.EXTRA_DETAIL, nw.getDetail());
        detailIntent.putExtra(DetailSf9.EXTRA_LAHIR, nw.getLahir());
        detailIntent.putExtra(DetailSf9.EXTRA_POSISI, nw.getPosisi());
        startActivity(detailIntent);

    }
}
